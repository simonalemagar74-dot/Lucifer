# Lucifer (Version 1)

A personal AI assistant for Android. Talk or type; Lucifer answers (and speaks) using Google Gemini,
and can open apps, search, set alarms and remember things you ask it to.

## Honest status

Written but **not yet compiled or run by its author** (the build environment had no Android SDK).
The first GitHub build may reveal small errors; fix them and rebuild.

## What works (by design)
- Chat with Gemini (your own free API key, stored only on your phone)
- Voice in (Android speech recognition) and voice out (Android text-to-speech)
- "Live talk" mode: keeps listening after each answer
- Phone actions via normal Android intents: open app, open URL, Google search, YouTube search,
  open dialer (you press call), set alarm, set timer
- Memory: saved only when you ask; view / delete / clear / disable in Settings
- Orb UI with listening / thinking / speaking states

## What does NOT exist yet
Controlling other apps (tap/type), reading the screen, camera, OCR, PDFs, weather, wake word
("Hey Lucifer"), Code Lab, plugins, Security Lab, backup. These are planned for later versions.

## Permissions
- Internet: talk to Gemini
- Microphone: asked only when you first tap the orb
- Set alarm: lets the Clock app accept alarms/timers

## Privacy
Messages, saved memories and the current date/time are sent to Google's Gemini API.
Nothing is recorded in the background. The API key never leaves your phone except in the request
header to Google. Backups are disabled so the key is not copied to cloud backups.

## Project layout
- `ai/` Gemini client + the assistant loop (replaceable provider)
- `tools/PhoneActions.kt` the actions Lucifer can perform (validated, permission-light)
- `memory/` local memory store
- `voice/` speech recognition and text-to-speech
- `ui/` Compose screens and the orb
- `LuciferViewModel.kt` ties everything together

## Build
GitHub Actions builds the APK automatically (see `.github/workflows/build.yml`).
Locally: install Android Studio, open this folder, run `gradle assembleDebug`.
The APK is a **debug-signed** build, fine for personal use, not for the Play Store.

## Known limitations
- Gemini model names change; if you see "model not found", update the model name in Settings.
- Text-to-speech uses the phone's default language.
- Free Gemini keys have rate limits.
