# Changelog

## 0.1.0 - Version 1 (untested first build)
- Gemini chat with function calling
- Voice input and output, live talk mode
- Phone actions: open app, URL, web search, YouTube search, dialer, alarm, timer
- User-controlled memory
- Settings with privacy explanation
- Unit tests for Gemini JSON parsing and memory serialization
