package com.lucifer.assistant.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Something went wrong while listening. [quiet] = just "no speech heard", not worth an alarm. */
data class VoiceProblem(val message: String, val quiet: Boolean)

/**
 * Speech input (Android SpeechRecognizer) and speech output (Android TextToSpeech).
 * Must be created and used on the main thread. Microphone permission is requested by the UI
 * before [startListening] is called; Lucifer only listens after the user taps the orb.
 */
class VoiceManager(context: Context) {
    private val appContext = context.applicationContext
    private val main = Handler(Looper.getMainLooper())

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var utteranceCounter = 0
    private var currentUtterance: String? = null

    init {
        tts = TextToSpeech(appContext) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) {
                val r = tts?.setLanguage(Locale.getDefault())
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts?.setLanguage(Locale.US)
                }
            }
        }
    }

    fun startListening(
        onPartial: (String) -> Unit,
        onFinal: (String) -> Unit,
        onProblem: (VoiceProblem) -> Unit
    ) {
        stopListening()
        if (!SpeechRecognizer.isRecognitionAvailable(appContext)) {
            onProblem(
                VoiceProblem(
                    "Speech recognition isn't available on this phone. Make sure the Google app is installed and enabled.",
                    false
                )
            )
            return
        }
        val r = SpeechRecognizer.createSpeechRecognizer(appContext)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onPartialResults(partialResults: Bundle?) {
                val t = partialResults
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull().orEmpty()
                if (t.isNotBlank()) onPartial(t)
            }

            override fun onResults(results: Bundle?) {
                val t = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull().orEmpty()
                stopListening()
                if (t.isBlank()) {
                    onProblem(VoiceProblem("I didn't catch that. Tap the orb and try again.", true))
                } else {
                    onFinal(t)
                }
            }

            override fun onError(error: Int) {
                stopListening()
                onProblem(describe(error))
            }
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        r.startListening(intent)
    }

    fun stopListening() {
        recognizer?.let {
            try {
                it.cancel()
                it.destroy()
            } catch (e: Exception) {
                // Already released; nothing to do.
            }
        }
        recognizer = null
    }

    /** Speaks [text], then calls [onFinished] on the main thread (also if speech fails). */
    fun speak(text: String, onFinished: () -> Unit) {
        val engine = tts
        if (engine == null || !ttsReady) {
            onFinished()
            return
        }
        val clean = text.replace(Regex("[*_#`>]"), "").trim().take(MAX_SPEECH_CHARS)
        if (clean.isEmpty()) {
            onFinished()
            return
        }
        val id = "lucifer-${utteranceCounter++}"
        currentUtterance = id
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}

            override fun onDone(utteranceId: String?) {
                finish(utteranceId)
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                finish(utteranceId)
            }

            override fun onError(utteranceId: String?, errorCode: Int) {
                finish(utteranceId)
            }

            private fun finish(utteranceId: String?) {
                main.post {
                    if (utteranceId != null && utteranceId == currentUtterance) {
                        currentUtterance = null
                        onFinished()
                    }
                }
            }
        })
        val result = engine.speak(clean, TextToSpeech.QUEUE_FLUSH, null, id)
        if (result != TextToSpeech.SUCCESS) {
            currentUtterance = null
            onFinished()
        }
    }

    fun stopSpeaking() {
        currentUtterance = null
        tts?.stop()
    }

    fun shutdown() {
        stopListening()
        stopSpeaking()
        tts?.shutdown()
        tts = null
    }

    private fun describe(code: Int): VoiceProblem = when (code) {
        SpeechRecognizer.ERROR_NO_MATCH,
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
            VoiceProblem("I didn't hear anything. Tap the orb and try again.", true)
        SpeechRecognizer.ERROR_CLIENT ->
            VoiceProblem("Listening was cancelled.", true)
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
            VoiceProblem("Microphone permission is missing. Allow it in your phone's app settings.", false)
        SpeechRecognizer.ERROR_NETWORK,
        SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
            VoiceProblem("Speech recognition needs internet and couldn't connect.", false)
        SpeechRecognizer.ERROR_AUDIO ->
            VoiceProblem("There was a problem with the microphone.", false)
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY ->
            VoiceProblem("The speech service is busy. Try again in a moment.", false)
        else -> VoiceProblem("Speech recognition failed (code $code). Try again.", false)
    }

    companion object {
        private const val MAX_SPEECH_CHARS = 3500
    }
}
