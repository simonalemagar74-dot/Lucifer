package com.lucifer.assistant

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.lucifer.assistant.ui.LuciferScreen
import com.lucifer.assistant.ui.LuciferTheme
import com.lucifer.assistant.ui.SettingsScreen

class MainActivity : ComponentActivity() {
    private val viewModel: LuciferViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            LuciferTheme {
                LuciferRoot(viewModel)
            }
        }
    }
}

@Composable
private fun LuciferRoot(vm: LuciferViewModel) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val memory by vm.memoryEntries.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var showSettings by rememberSaveable { mutableStateOf(false) }

    val micPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) vm.startVoice() else vm.onMicDenied()
    }

    fun onMic() {
        if (ui.orb != OrbState.IDLE) {
            vm.onOrbPressedWhileBusy()
            return
        }
        val granted = ContextCompat.checkSelfPermission(
            context, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        if (granted) vm.startVoice() else micPermission.launch(Manifest.permission.RECORD_AUDIO)
    }

    BackHandler(enabled = showSettings) { showSettings = false }

    if (showSettings) {
        SettingsScreen(
            settings = settings,
            memory = memory,
            onChange = vm::updateSettings,
            onDeleteMemory = vm::deleteMemory,
            onClearMemory = vm::clearMemory,
            onNewChat = vm::newChat,
            onClose = { showSettings = false }
        )
    } else {
        LuciferScreen(
            ui = ui,
            onSend = { vm.send(it) },
            onMic = { onMic() },
            onLiveChange = vm::setLive,
            onOpenSettings = { showSettings = true }
        )
    }
}
