package com.lucifer.assistant.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object LuciferColors {
    val BgTop = Color(0xFF14121C)
    val BgBottom = Color(0xFF07070C)
    val Ember = Color(0xFFFF3B3B)
    val Amber = Color(0xFFFF9A3C)
    val Cyan = Color(0xFF3BD9FF)
    val Rose = Color(0xFFFF6FA8)
    val Surface = Color(0xFF181824)
    val UserBubble = Color(0xFF3A1519)
    val Text = Color(0xFFECECF4)
    val TextDim = Color(0xFF9A9AB0)
}

@Composable
fun LuciferTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = LuciferColors.Ember,
            onPrimary = Color.White,
            secondary = LuciferColors.Amber,
            background = LuciferColors.BgBottom,
            onBackground = LuciferColors.Text,
            surface = LuciferColors.Surface,
            onSurface = LuciferColors.Text,
            error = Color(0xFFFF6B6B)
        ),
        content = content
    )
}
