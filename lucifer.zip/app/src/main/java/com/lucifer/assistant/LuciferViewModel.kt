package com.lucifer.assistant

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.lucifer.assistant.ai.Assistant
import com.lucifer.assistant.ai.GeminiClient
import com.lucifer.assistant.data.Prefs
import com.lucifer.assistant.data.SettingsState
import com.lucifer.assistant.memory.MemoryEntry
import com.lucifer.assistant.memory.MemoryStore
import com.lucifer.assistant.tools.PhoneActions
import com.lucifer.assistant.voice.VoiceManager
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONArray

enum class OrbState { IDLE, LISTENING, THINKING, SPEAKING }

enum class MessageKind { USER, ASSISTANT, TOOL, ERROR }

data class ChatMessage(val id: Long, val kind: MessageKind, val text: String)

data class UiState(
    val messages: List<ChatMessage> = emptyList(),
    val orb: OrbState = OrbState.IDLE,
    val partial: String = "",
    val live: Boolean = false
)

class LuciferViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = Prefs(app)
    private val memory = MemoryStore(app)

    private val _settings = MutableStateFlow(prefs.read())
    val settings: StateFlow<SettingsState> = _settings.asStateFlow()
    val memoryEntries: StateFlow<List<MemoryEntry>> = memory.entries

    private val tools = PhoneActions(app, memory) { _settings.value.memoryEnabled }
    private val assistant = Assistant(GeminiClient(), tools, memory)
    private val voice = VoiceManager(app)

    private val contents = JSONArray()
    private var job: Job? = null
    private var nextId = 0L

    private val _ui = MutableStateFlow(UiState())
    val ui: StateFlow<UiState> = _ui.asStateFlow()

    init {
        addMessage(MessageKind.ASSISTANT, welcomeText())
    }

    // ---- sending ----

    fun send(text: String, viaVoice: Boolean = false) {
        val clean = text.trim()
        if (clean.isEmpty() || job?.isActive == true) return
        val s = _settings.value
        addMessage(MessageKind.USER, clean)
        if (s.apiKey.isBlank()) {
            addMessage(MessageKind.ERROR, "I need your Gemini API key first. Open Settings and paste it in.")
            return
        }
        setOrb(OrbState.THINKING)
        job = viewModelScope.launch {
            try {
                val answer = assistant.reply(s, contents, clean) { note ->
                    addMessage(MessageKind.TOOL, note)
                }
                addMessage(MessageKind.ASSISTANT, answer)
                if (viaVoice || s.speakTyped) {
                    speakAnswer(answer, resumeListening = viaVoice)
                } else {
                    setOrb(OrbState.IDLE)
                }
            } catch (e: CancellationException) {
                setOrb(OrbState.IDLE)
                throw e
            } catch (e: Exception) {
                addMessage(MessageKind.ERROR, e.message ?: "Something went wrong.")
                _ui.update { it.copy(live = false) }
                setOrb(OrbState.IDLE)
            }
        }
    }

    private fun speakAnswer(answer: String, resumeListening: Boolean) {
        setOrb(OrbState.SPEAKING)
        voice.speak(answer) {
            setOrb(OrbState.IDLE)
            if (resumeListening && _ui.value.live) startVoice()
        }
    }

    // ---- voice ----

    /** Call only after microphone permission has been granted. */
    fun startVoice() {
        if (job?.isActive == true) return
        voice.stopSpeaking()
        setOrb(OrbState.LISTENING)
        _ui.update { it.copy(partial = "") }
        voice.startListening(
            onPartial = { t -> _ui.update { it.copy(partial = t) } },
            onFinal = { t ->
                _ui.update { it.copy(partial = "") }
                send(t, viaVoice = true)
            },
            onProblem = { p ->
                _ui.update { it.copy(partial = "") }
                setOrb(OrbState.IDLE)
                if (_ui.value.live && p.quiet) {
                    _ui.update { it.copy(live = false) }
                } else {
                    addMessage(MessageKind.ERROR, p.message)
                    if (!p.quiet) _ui.update { it.copy(live = false) }
                }
            }
        )
    }

    /** The orb was tapped while Lucifer was busy: stop whatever it is doing. */
    fun onOrbPressedWhileBusy() {
        when (_ui.value.orb) {
            OrbState.LISTENING -> {
                voice.stopListening()
                _ui.update { it.copy(partial = "", live = false) }
                setOrb(OrbState.IDLE)
            }
            OrbState.SPEAKING -> {
                voice.stopSpeaking()
                _ui.update { it.copy(live = false) }
                setOrb(OrbState.IDLE)
            }
            OrbState.THINKING -> {
                _ui.update { it.copy(live = false) }
                job?.cancel()
            }
            OrbState.IDLE -> Unit
        }
    }

    fun onMicDenied() {
        addMessage(
            MessageKind.ERROR,
            "Microphone permission was denied, so I can't listen. You can still type to me, or allow the microphone in your phone's app settings."
        )
    }

    fun setLive(enabled: Boolean) {
        _ui.update { it.copy(live = enabled) }
    }

    // ---- settings / memory / chat ----

    fun updateSettings(new: SettingsState) {
        prefs.write(new)
        _settings.value = prefs.read()
    }

    fun deleteMemory(id: String) = memory.remove(id)

    fun clearMemory() = memory.clear()

    fun newChat() {
        job?.cancel()
        voice.stopListening()
        voice.stopSpeaking()
        while (contents.length() > 0) contents.remove(contents.length() - 1)
        _ui.value = UiState(
            messages = listOf(ChatMessage(nextId++, MessageKind.ASSISTANT, welcomeText()))
        )
    }

    // ---- internals ----

    private fun welcomeText(): String =
        if (_settings.value.apiKey.isBlank()) {
            "Hi, I'm Lucifer. To wake me up, open Settings and paste your free Gemini API key."
        } else {
            "Hi, I'm Lucifer. Tap the orb and talk to me, or type below."
        }

    private fun addMessage(kind: MessageKind, text: String) {
        _ui.update { it.copy(messages = it.messages + ChatMessage(nextId++, kind, text)) }
    }

    private fun setOrb(state: OrbState) {
        _ui.update { it.copy(orb = state) }
    }

    override fun onCleared() {
        job?.cancel()
        voice.shutdown()
        super.onCleared()
    }
}
