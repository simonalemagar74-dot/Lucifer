package com.lucifer.assistant.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.lucifer.assistant.OrbState

/** Lucifer's animated "face". Tap it to talk, or to stop whatever it is doing. */
@Composable
fun Orb(state: OrbState, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val transition = rememberInfiniteTransition(label = "orb")
    val pulse by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1100, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )
    val spin by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(3600, easing = LinearEasing)),
        label = "spin"
    )
    val color by animateColorAsState(
        targetValue = when (state) {
            OrbState.IDLE -> LuciferColors.Ember
            OrbState.LISTENING -> LuciferColors.Cyan
            OrbState.THINKING -> LuciferColors.Amber
            OrbState.SPEAKING -> LuciferColors.Rose
        },
        label = "orbColor"
    )
    val amplitude = when (state) {
        OrbState.IDLE -> 0.04f
        OrbState.LISTENING -> 0.14f
        OrbState.THINKING -> 0.07f
        OrbState.SPEAKING -> 0.18f
    }
    val ringSweep = if (state == OrbState.THINKING) 150f else 70f
    val description = when (state) {
        OrbState.IDLE -> "Lucifer. Tap to talk."
        OrbState.LISTENING -> "Lucifer is listening. Tap to stop."
        OrbState.THINKING -> "Lucifer is thinking. Tap to cancel."
        OrbState.SPEAKING -> "Lucifer is speaking. Tap to stop."
    }

    Canvas(
        modifier = modifier
            .semantics { contentDescription = description }
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                role = Role.Button,
                onClick = onClick
            )
    ) {
        val c = center
        val r = size.minDimension / 2f
        val scale = 1f + amplitude * pulse

        // Soft outer glow.
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(color.copy(alpha = 0.40f), Color.Transparent),
                center = c,
                radius = r
            ),
            radius = r,
            center = c
        )
        // Glowing core.
        val coreR = r * 0.48f * scale
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color.White.copy(alpha = 0.95f), color, color.copy(alpha = 0.15f)),
                center = c,
                radius = coreR
            ),
            radius = coreR,
            center = c
        )
        // Two rotating rings.
        val stroke = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
        val ring1 = r * 0.70f
        drawArc(
            color = color,
            startAngle = spin,
            sweepAngle = ringSweep,
            useCenter = false,
            topLeft = Offset(c.x - ring1, c.y - ring1),
            size = Size(ring1 * 2, ring1 * 2),
            style = stroke
        )
        val ring2 = r * 0.86f
        drawArc(
            color = color.copy(alpha = 0.6f),
            startAngle = -spin * 0.7f + 180f,
            sweepAngle = ringSweep * 0.8f,
            useCenter = false,
            topLeft = Offset(c.x - ring2, c.y - ring2),
            size = Size(ring2 * 2, ring2 * 2),
            style = stroke
        )
    }
}
