package com.lucifer.assistant.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lucifer.assistant.ChatMessage
import com.lucifer.assistant.MessageKind
import com.lucifer.assistant.OrbState
import com.lucifer.assistant.UiState

@Composable
fun LuciferScreen(
    ui: UiState,
    onSend: (String) -> Unit,
    onMic: () -> Unit,
    onLiveChange: (Boolean) -> Unit,
    onOpenSettings: () -> Unit
) {
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(ui.messages.size) {
        if (ui.messages.isNotEmpty()) listState.animateScrollToItem(ui.messages.size - 1)
    }

    fun submit() {
        if (input.isNotBlank() && ui.orb == OrbState.IDLE) {
            onSend(input)
            input = ""
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(LuciferColors.BgTop, LuciferColors.BgBottom)))
            .systemBarsPadding()
            .imePadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 20.dp, end = 8.dp, top = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    "LUCIFER",
                    color = LuciferColors.Text,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    letterSpacing = 4.sp
                )
                Text(statusLabel(ui.orb), color = LuciferColors.TextDim, fontSize = 13.sp)
            }
            TextButton(onClick = onOpenSettings) { Text("⚙ Settings", color = LuciferColors.TextDim) }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp),
            contentAlignment = Alignment.Center
        ) {
            val orbSize = if (ui.messages.size <= 1) 190.dp else 112.dp
            Orb(state = ui.orb, modifier = Modifier.size(orbSize), onClick = onMic)
        }

        if (ui.partial.isNotBlank()) {
            Text(
                ui.partial,
                color = LuciferColors.Cyan,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 4.dp),
                textAlign = TextAlign.Center
            )
        }

        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(ui.messages, key = { it.id }) { MessageRow(it) }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Switch(checked = ui.live, onCheckedChange = onLiveChange)
            Spacer(Modifier.width(10.dp))
            Text(
                "Live talk: keep listening after I answer",
                color = LuciferColors.TextDim,
                fontSize = 13.sp
            )
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Message Lucifer") },
                maxLines = 4,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { submit() })
            )
            Spacer(Modifier.width(8.dp))
            if (input.isNotBlank()) {
                Button(onClick = { submit() }, enabled = ui.orb == OrbState.IDLE) { Text("Send") }
            } else {
                Button(onClick = onMic) { Text(if (ui.orb == OrbState.IDLE) "🎤" else "■") }
            }
        }
    }
}

private fun statusLabel(orb: OrbState): String = when (orb) {
    OrbState.IDLE -> "Tap the orb to talk"
    OrbState.LISTENING -> "Listening…"
    OrbState.THINKING -> "Thinking… (tap to cancel)"
    OrbState.SPEAKING -> "Speaking… (tap to stop)"
}

@Composable
private fun MessageRow(m: ChatMessage) {
    when (m.kind) {
        MessageKind.USER -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            Bubble(m.text, LuciferColors.UserBubble, LuciferColors.Text)
        }
        MessageKind.ASSISTANT -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
            Bubble(m.text, LuciferColors.Surface, LuciferColors.Text)
        }
        MessageKind.TOOL -> Text(
            "⚙ ${m.text}",
            color = LuciferColors.Amber,
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 8.dp)
        )
        MessageKind.ERROR -> Text(
            m.text,
            color = MaterialTheme.colorScheme.error,
            fontSize = 14.sp,
            modifier = Modifier.padding(horizontal = 8.dp)
        )
    }
}

@Composable
private fun Bubble(text: String, background: androidx.compose.ui.graphics.Color, textColor: androidx.compose.ui.graphics.Color) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = background,
        modifier = Modifier.widthIn(max = 310.dp)
    ) {
        Text(
            text,
            color = textColor,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
        )
    }
}
