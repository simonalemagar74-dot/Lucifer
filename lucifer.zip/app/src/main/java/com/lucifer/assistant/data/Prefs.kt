package com.lucifer.assistant.data

import android.content.Context

/** Everything the user can configure. Kept on this phone only. */
data class SettingsState(
    val apiKey: String = "",
    val model: String = Prefs.DEFAULT_MODEL,
    val speakTyped: Boolean = false,
    val userName: String = "",
    val memoryEnabled: Boolean = true
)

class Prefs(context: Context) {
    private val sp = context.applicationContext
        .getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun read(): SettingsState = SettingsState(
        apiKey = sp.getString(K_KEY, "").orEmpty(),
        model = sp.getString(K_MODEL, DEFAULT_MODEL).orEmpty().ifBlank { DEFAULT_MODEL },
        speakTyped = sp.getBoolean(K_SPEAK_TYPED, false),
        userName = sp.getString(K_NAME, "").orEmpty(),
        memoryEnabled = sp.getBoolean(K_MEMORY, true)
    )

    fun write(s: SettingsState) {
        sp.edit()
            .putString(K_KEY, s.apiKey.trim())
            .putString(K_MODEL, s.model.trim().ifBlank { DEFAULT_MODEL })
            .putBoolean(K_SPEAK_TYPED, s.speakTyped)
            .putString(K_NAME, s.userName.trim())
            .putBoolean(K_MEMORY, s.memoryEnabled)
            .apply()
    }

    companion object {
        /** Change this in Settings if Google retires it. Verified against Google's model list. */
        const val DEFAULT_MODEL = "gemini-3.5-flash"

        private const val FILE = "lucifer_prefs"
        private const val K_KEY = "api_key"
        private const val K_MODEL = "model"
        private const val K_SPEAK_TYPED = "speak_typed"
        private const val K_NAME = "user_name"
        private const val K_MEMORY = "memory_enabled"
    }
}
