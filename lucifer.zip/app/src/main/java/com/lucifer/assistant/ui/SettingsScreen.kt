package com.lucifer.assistant.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lucifer.assistant.data.SettingsState
import com.lucifer.assistant.memory.MemoryEntry

@Composable
fun SettingsScreen(
    settings: SettingsState,
    memory: List<MemoryEntry>,
    onChange: (SettingsState) -> Unit,
    onDeleteMemory: (String) -> Unit,
    onClearMemory: () -> Unit,
    onNewChat: () -> Unit,
    onClose: () -> Unit
) {
    // Local copies so typing never fights with state updates.
    var apiKey by remember { mutableStateOf(settings.apiKey) }
    var model by remember { mutableStateOf(settings.model) }
    var name by remember { mutableStateOf(settings.userName) }
    var showKey by remember { mutableStateOf(false) }
    var confirmClear by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(LuciferColors.BgBottom)
            .systemBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Settings",
                color = LuciferColors.Text,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            Button(onClick = onClose) { Text("Done") }
        }

        Section("AI brain (Google Gemini)")
        Hint("Get a free key at aistudio.google.com on your phone, then paste it here. It stays on this phone only.")
        OutlinedTextField(
            value = apiKey,
            onValueChange = {
                apiKey = it
                onChange(settings.copy(apiKey = it, model = model, userName = name))
            },
            label = { Text("Gemini API key") },
            singleLine = true,
            visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            modifier = Modifier.fillMaxWidth()
        )
        TextButton(onClick = { showKey = !showKey }) { Text(if (showKey) "Hide key" else "Show key") }
        OutlinedTextField(
            value = model,
            onValueChange = {
                model = it
                onChange(settings.copy(apiKey = apiKey, model = it, userName = name))
            },
            label = { Text("Model name") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Hint("If you see \"model not found\", Google retired this name. Check ai.google.dev/gemini-api/docs/models and paste a current one.")

        Section("You")
        OutlinedTextField(
            value = name,
            onValueChange = {
                name = it
                onChange(settings.copy(apiKey = apiKey, model = model, userName = it))
            },
            label = { Text("Your name (optional)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Section("Voice")
        ToggleRow(
            "Also speak answers to typed messages",
            settings.speakTyped
        ) { onChange(settings.copy(apiKey = apiKey, model = model, userName = name, speakTyped = it)) }
        Hint("Answers to your voice are always spoken. Lucifer only listens after you tap the orb.")

        Section("Memory")
        ToggleRow("Let Lucifer remember things", settings.memoryEnabled) {
            onChange(settings.copy(apiKey = apiKey, model = model, userName = name, memoryEnabled = it))
        }
        Hint("Lucifer saves something only when you ask (\"remember that...\"). Everything saved is listed here and can be deleted.")
        if (memory.isEmpty()) {
            Text("Nothing saved yet.", color = LuciferColors.TextDim)
        } else {
            memory.forEach { entry ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(entry.text, color = LuciferColors.Text, modifier = Modifier.weight(1f))
                    TextButton(onClick = { onDeleteMemory(entry.id) }) { Text("Delete") }
                }
            }
            OutlinedButton(onClick = { confirmClear = true }) { Text("Delete all memory") }
        }

        Section("Conversation")
        OutlinedButton(onClick = { onNewChat(); onClose() }) { Text("Start a new conversation") }

        Section("Privacy")
        Hint(
            "What leaves your phone: the messages you send, the memories above, and the current date/time are sent to Google's Gemini API to get answers. " +
                "Voice is converted to text by your phone's speech service (Google's, which may use the internet). " +
                "Lucifer does not record in the background, and uses the microphone only after you tap the orb. " +
                "It cannot read your screen, camera, contacts or messages."
        )
        Spacer(Modifier.height(24.dp))
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Delete all memory?") },
            text = { Text("This permanently deletes everything Lucifer has saved about you.") },
            confirmButton = {
                TextButton(onClick = { onClearMemory(); confirmClear = false }) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { confirmClear = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun Section(title: String) {
    Spacer(Modifier.height(22.dp))
    Text(title, color = LuciferColors.Amber, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    Spacer(Modifier.height(6.dp))
}

@Composable
private fun Hint(text: String) {
    Text(
        text,
        color = LuciferColors.TextDim,
        fontSize = 13.sp,
        modifier = Modifier.padding(vertical = 4.dp)
    )
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = LuciferColors.Text, modifier = Modifier.weight(1f))
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onChecked)
    }
}
