package com.lucifer.assistant.ai

import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class GeminiException(message: String, val httpCode: Int = 0) : Exception(message)

data class ToolCall(val name: String, val id: String?, val args: JSONObject)

/** Pure JSON helpers (unit-tested). */
object GeminiParser {
    /** Returns the first candidate's "content" object, or null if the model gave none. */
    fun candidateContent(body: String): JSONObject? {
        val candidates = JSONObject(body).optJSONArray("candidates") ?: return null
        if (candidates.length() == 0) return null
        return candidates.getJSONObject(0).optJSONObject("content")
    }

    fun text(content: JSONObject): String {
        val parts = content.optJSONArray("parts") ?: return ""
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            val p = parts.getJSONObject(i)
            if (p.has("text") && !p.optBoolean("thought", false)) sb.append(p.getString("text"))
        }
        return sb.toString().trim()
    }

    fun toolCalls(content: JSONObject): List<ToolCall> {
        val parts = content.optJSONArray("parts") ?: return emptyList()
        val calls = ArrayList<ToolCall>()
        for (i in 0 until parts.length()) {
            val fc = parts.getJSONObject(i).optJSONObject("functionCall") ?: continue
            val name = fc.optString("name")
            if (name.isEmpty()) continue
            val id = if (fc.has("id")) fc.optString("id") else null
            calls.add(ToolCall(name, id, fc.optJSONObject("args") ?: JSONObject()))
        }
        return calls
    }

    fun errorMessage(body: String): String? = try {
        JSONObject(body).optJSONObject("error")?.optString("message")
    } catch (e: Exception) {
        null
    }

    fun blockReason(body: String): String? = try {
        JSONObject(body).optJSONObject("promptFeedback")?.optString("blockReason")
            ?.takeIf { it.isNotEmpty() }
    } catch (e: Exception) {
        null
    }
}

/**
 * Talks to Google's Gemini API directly from the phone using the user's own key.
 * The key is sent only in the request header and is never logged or shown.
 */
class GeminiClient(
    private val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .build()
) {
    /**
     * Sends the conversation and returns the model's reply "content" object, exactly as
     * received (Gemini requires it be sent back unchanged on the next turn).
     */
    suspend fun generate(
        apiKey: String,
        model: String,
        systemText: String,
        contents: JSONArray,
        tools: JSONArray
    ): JSONObject {
        val cleanModel = model.trim().removePrefix("models/")
        if (!MODEL_REGEX.matches(cleanModel)) {
            throw GeminiException("The model name \"$cleanModel\" looks invalid. Fix it in Settings.")
        }
        val url = "$BASE/$cleanModel:generateContent"
        val body = JSONObject()
            .put(
                "systemInstruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemText)))
            )
            .put("contents", contents)
            .put("tools", tools)
            .toString()

        var lastError: GeminiException? = null
        for (attempt in 0..1) {
            val (code, text) = try {
                post(url, apiKey, body)
            } catch (e: IOException) {
                throw GeminiException("Can't reach Gemini. Check your internet connection and try again.")
            }
            if (code == 200) {
                val content = GeminiParser.candidateContent(text)
                if (content != null) return content
                val blocked = GeminiParser.blockReason(text)
                throw GeminiException(
                    if (blocked != null) "Gemini refused that request ($blocked)."
                    else "Gemini returned an empty answer. Try rephrasing."
                )
            }
            lastError = GeminiException(friendly(code, text, cleanModel), code)
            val retryable = code == 429 || code == 500 || code == 503
            if (!retryable || attempt == 1) break
            delay(1500)
        }
        throw lastError ?: GeminiException("Unknown Gemini error.")
    }

    private suspend fun post(url: String, apiKey: String, json: String): Pair<Int, String> =
        suspendCancellableCoroutine { cont ->
            val request = Request.Builder()
                .url(url)
                .header("x-goog-api-key", apiKey)
                .post(json.toRequestBody("application/json".toMediaType()))
                .build()
            val call = http.newCall(request)
            cont.invokeOnCancellation { call.cancel() }
            call.enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    if (cont.isActive) cont.resumeWithException(e)
                }

                override fun onResponse(call: Call, response: Response) {
                    try {
                        val result = response.use { it.code to it.body?.string().orEmpty() }
                        if (cont.isActive) cont.resume(result)
                    } catch (e: IOException) {
                        if (cont.isActive) cont.resumeWithException(e)
                    }
                }
            })
        }

    private fun friendly(code: Int, body: String, model: String): String {
        val detail = GeminiParser.errorMessage(body).orEmpty()
        return when {
            code == 400 && detail.contains("API key", ignoreCase = true) ->
                "Gemini says your API key is not valid. Re-paste it in Settings."
            code == 400 -> "Gemini rejected the request: ${detail.take(200)}"
            code == 401 || code == 403 ->
                "Gemini refused access. Check that your API key is correct and enabled."
            code == 404 ->
                "The model \"$model\" was not found. Open Settings and change the model name."
            code == 429 ->
                "Gemini's free limit was reached. Wait a minute and try again."
            code >= 500 -> "Gemini is busy right now. Try again in a moment."
            else -> "Gemini error $code: ${detail.take(200)}"
        }
    }

    companion object {
        private const val BASE = "https://generativelanguage.googleapis.com/v1beta/models"
        private val MODEL_REGEX = Regex("^[A-Za-z0-9._-]{3,80}$")
    }
}
