package com.lucifer.assistant.tools

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import com.lucifer.assistant.memory.MemoryStore
import org.json.JSONArray
import org.json.JSONObject

/**
 * The things Lucifer can actually do on the phone. Each action uses a normal, public Android
 * mechanism (intents) - nothing hidden, nothing that bypasses Android's security.
 *
 * Every result string starts with "OK:" or "ERROR:" so the AI can report honestly.
 * Model-supplied arguments are treated as untrusted and validated here.
 */
class PhoneActions(
    private val context: Context,
    private val memory: MemoryStore,
    private val memoryEnabled: () -> Boolean
) {

    fun declarations(): JSONArray {
        val fns = JSONArray()
        fns.put(
            fn(
                "open_app",
                "Open an installed app on the phone by its name, e.g. YouTube, WhatsApp, Camera, Settings.",
                JSONObject().put("app_name", str("Name of the app as shown on the home screen")),
                listOf("app_name")
            )
        )
        fns.put(
            fn(
                "open_url",
                "Open a web page (http or https) in the browser.",
                JSONObject().put("url", str("Full web address")),
                listOf("url")
            )
        )
        fns.put(
            fn(
                "search_web",
                "Open a Google search for the given text in the browser.",
                JSONObject().put("query", str("What to search for")),
                listOf("query")
            )
        )
        fns.put(
            fn(
                "search_youtube",
                "Open YouTube search results for the given text. Does not auto-play.",
                JSONObject().put("query", str("What to search for on YouTube")),
                listOf("query")
            )
        )
        fns.put(
            fn(
                "dial_number",
                "Open the phone dialer with a number filled in. The user still has to press the call button.",
                JSONObject().put("phone_number", str("Phone number, digits with optional + ( ) - and spaces")),
                listOf("phone_number")
            )
        )
        fns.put(
            fn(
                "set_alarm",
                "Set an alarm in the Clock app at a given time (24-hour clock).",
                JSONObject()
                    .put("hour", int("Hour 0-23"))
                    .put("minute", int("Minute 0-59"))
                    .put("label", str("Short label for the alarm")),
                listOf("hour", "minute")
            )
        )
        fns.put(
            fn(
                "set_timer",
                "Start a countdown timer in the Clock app.",
                JSONObject()
                    .put("seconds", int("Length of the timer in seconds"))
                    .put("label", str("Short label for the timer")),
                listOf("seconds")
            )
        )
        fns.put(
            fn(
                "remember",
                "Save one short fact or preference to the user's private memory. Only use when the user asks you to remember something.",
                JSONObject().put("fact", str("The fact to remember, written as a short sentence")),
                listOf("fact")
            )
        )
        fns.put(
            fn(
                "forget",
                "Delete saved memories that contain the given text. Only use when the user asks you to forget something.",
                JSONObject().put("text", str("Text to match in saved memories")),
                listOf("text")
            )
        )
        return JSONArray().put(JSONObject().put("functionDeclarations", fns))
    }

    /** Runs a tool. Never throws; failures come back as "ERROR: ..." text. */
    fun execute(name: String, args: JSONObject): String = try {
        when (name) {
            "open_app" -> openApp(args.optString("app_name"))
            "open_url" -> openUrl(args.optString("url"))
            "search_web" -> viewUri(
                "https://www.google.com/search?q=" + Uri.encode(args.optString("query")),
                "Google search"
            )
            "search_youtube" -> viewUri(
                "https://www.youtube.com/results?search_query=" + Uri.encode(args.optString("query")),
                "YouTube search results"
            )
            "dial_number" -> dial(args.optString("phone_number"))
            "set_alarm" -> setAlarm(args.optInt("hour", -1), args.optInt("minute", -1), args.optString("label"))
            "set_timer" -> setTimer(args.optInt("seconds", -1), args.optString("label"))
            "remember" -> remember(args.optString("fact"))
            "forget" -> forget(args.optString("text"))
            else -> "ERROR: unknown tool \"$name\""
        }
    } catch (e: Exception) {
        "ERROR: ${e.javaClass.simpleName} while running $name"
    }

    // ---- actions ----

    private fun openApp(requested: String): String {
        val q = requested.trim().lowercase()
        if (q.isEmpty()) return "ERROR: no app name given"
        val pm = context.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0)
        fun label(i: android.content.pm.ResolveInfo) = i.loadLabel(pm).toString()
        val match = apps.firstOrNull { label(it).lowercase() == q }
            ?: apps.firstOrNull { label(it).lowercase().contains(q) }
            ?: apps.firstOrNull { label(it).length >= 3 && q.contains(label(it).lowercase()) }
        if (match == null) {
            val names = apps.map { label(it) }.distinct().sorted().take(30).joinToString(", ")
            return "ERROR: no installed app matches \"$requested\". Some installed apps: $names"
        }
        val launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            ?: return "ERROR: ${label(match)} can't be launched"
        return if (start(launch)) "OK: opened ${label(match)}" else "ERROR: could not open ${label(match)}"
    }

    private fun openUrl(raw: String): String {
        var url = raw.trim()
        if (url.isEmpty()) return "ERROR: no address given"
        if (!url.startsWith("http://", true) && !url.startsWith("https://", true)) url = "https://$url"
        val uri = Uri.parse(url)
        if (uri.host.isNullOrEmpty()) return "ERROR: that is not a valid web address"
        return viewUri(url, uri.host ?: "web page")
    }

    private fun viewUri(url: String, what: String): String {
        val ok = start(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        return if (ok) "OK: opened $what" else "ERROR: no app could open $what"
    }

    private fun dial(raw: String): String {
        val number = raw.trim()
        if (!PHONE_REGEX.matches(number)) return "ERROR: that is not a valid phone number"
        val ok = start(Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", number, null)))
        return if (ok) "OK: opened the dialer with $number. The user must press call themselves."
        else "ERROR: no dialer app found"
    }

    private fun setAlarm(hour: Int, minute: Int, label: String): String {
        if (hour !in 0..23 || minute !in 0..59) return "ERROR: invalid time"
        val intent = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, hour)
            .putExtra(AlarmClock.EXTRA_MINUTES, minute)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label.take(60))
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        val time = "%02d:%02d".format(hour, minute)
        return if (start(intent)) "OK: sent alarm for $time to the Clock app" else "ERROR: no Clock app could set the alarm"
    }

    private fun setTimer(seconds: Int, label: String): String {
        if (seconds !in 1..86_400) return "ERROR: timer must be between 1 second and 24 hours"
        val intent = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label.take(60))
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return if (start(intent)) "OK: sent a $seconds second timer to the Clock app" else "ERROR: no Clock app could set the timer"
    }

    private fun remember(fact: String): String {
        if (!memoryEnabled()) return "ERROR: memory is turned off in Settings"
        return if (memory.add(fact) != null) "OK: saved to memory" else "ERROR: nothing to save"
    }

    private fun forget(text: String): String {
        if (!memoryEnabled()) return "ERROR: memory is turned off in Settings"
        val n = memory.removeMatching(text)
        return if (n > 0) "OK: deleted $n memory item(s)" else "ERROR: no saved memory matches that"
    }

    // ---- helpers ----

    private fun start(intent: Intent): Boolean = try {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        true
    } catch (e: ActivityNotFoundException) {
        false
    } catch (e: SecurityException) {
        false
    }

    private fun str(desc: String) = JSONObject().put("type", "string").put("description", desc)
    private fun int(desc: String) = JSONObject().put("type", "integer").put("description", desc)

    private fun fn(name: String, desc: String, props: JSONObject, required: List<String>): JSONObject =
        JSONObject()
            .put("name", name)
            .put("description", desc)
            .put(
                "parameters",
                JSONObject()
                    .put("type", "object")
                    .put("properties", props)
                    .put("required", JSONArray(required))
            )

    companion object {
        private val PHONE_REGEX = Regex("^[+0-9 ()\\-]{3,20}$")
    }
}
