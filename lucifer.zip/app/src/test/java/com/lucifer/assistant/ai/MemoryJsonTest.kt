package com.lucifer.assistant.ai

import com.lucifer.assistant.memory.MemoryEntry
import com.lucifer.assistant.memory.MemoryStore
import org.junit.Assert.assertEquals
import org.junit.Test

class MemoryJsonTest {
    @Test
    fun roundTrip() {
        val list = listOf(
            MemoryEntry("1", "My favourite colour is red", 100L),
            MemoryEntry("2", "I wake up at 6", 200L)
        )
        assertEquals(list, MemoryStore.fromJson(MemoryStore.toJson(list)))
    }

    @Test(expected = Exception::class)
    fun corruptedJsonThrows() {
        MemoryStore.fromJson("{{ not json")
    }
}
